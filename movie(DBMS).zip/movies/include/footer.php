<div class="footer">
			</div>
			<div class="copy-rights text-center">
				<p>&copy;  Design by <a href="">Keerthika and Shreenidhi</a></p>
			</div>
	</div>
</body>
</html>